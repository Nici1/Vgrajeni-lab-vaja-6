#include <asf.h>
#include <rtos_tasks.h>
#include <rtos.h>
#include <ioport.h>
#include <test-more.h>
#include <lcd.h>

uint32_t time2=0;
uint32_t time=0;
int sekunde =0;
uint8_t minute =0;
uint8_t ure =0;

rtos_task_t task_blink = {
    .last_tick=0,
    .name="blink",
    .fun=blink_driver
};

rtos_task_t task_gonilnik_ure = {
    .last_tick=0,
    .name="gonilnik ure",
    .fun=clock_task
};

rtos_task_t task_priprava_tekst = {
    .last_tick=1,
    .name="priprava tekst",
    .fun=text_task
};
rtos_task_t task_gonilnik_lcd = {
    .last_tick=2,
    .name="gonilnik lcd",
    .fun=lcd_task
};
rtos_task_t task_gonilnik_tipke = {
    .last_tick=3,
    .name="gonilnik tipke",
    .fun=btn_task
};



void blink_driver(void){
ioport_toggle_pin_level(L1_IDX);
}

void clock_task(void){

time=time2/100;
//forata so ova e da se proveruva poveke pati
//vo sekunda t.e 100 so cel da bidat kopcinjata po responsive
sekunde=time % 60;
if(sekunde==0 && time>0){
minute++;
//sekunde=sekunde%60
}

minute=minute %60;
if(minute==0 && time>60){

ure++;
}


ure = ure % 24;

time2++;
}

void text_task(void){
int konec= sprintf(lcd_string,"%02u : %02u : %02u",ure,minute,sekunde);
lcd_string[konec]=' ';
}

void btn_task(void){
        int btn;
        int btn3;
        btn = get_btn_press();
        btn3=get_btn_state(); // state e potreben bidejki raboti na pozitivni vrednosti a ne na front
        if ((btn & (1<<0) )!= 0)
        {
            ure += 1;
        }


        if ((btn & (1<<1) )!= 0)
        {
            minute += 1;
        }


        if((btn3 & (1<<2) )!= 0)
        {
            time2--;
        }


        if ((btn & (1<<3) )!= 0)
        {
            time2=0;
            minute=0;
            ure=0;
        }
}

void lcd_task(void){
lcd_driver();
}
rtos_task_t *rtos_task_list[]={&task_gonilnik_ure,&task_priprava_tekst,&task_gonilnik_lcd,&task_gonilnik_tipke,0};

#ifndef RTOS_H_INCLUDED
#define RTOS_H_INCLUDED

#include <asf.h>




// kazalec na funkcijo
typedef void (*ptr_function_t) (void);

struct rtos_task
{
    uint32_t last_tick;
    char name [15];
    ptr_function_t fun;
};

typedef struct rtos_task rtos_task_t;

uint32_t rtos_init(uint32_t slice_us);

void rtos_disable(void);

void rtos_enable(void);

#endif // RTOS_H_INCLUDED
